from django.contrib import admin
from .models import Disciplina

admin.site.register(Disciplina)