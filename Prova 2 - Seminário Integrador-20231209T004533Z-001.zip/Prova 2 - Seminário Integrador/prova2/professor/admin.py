from django.contrib import admin
from .models import Professor

admin.site.register(Professor)