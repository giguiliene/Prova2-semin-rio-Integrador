from django.contrib import admin
from .models import DetalheDisciplina

admin.site.register(DetalheDisciplina)